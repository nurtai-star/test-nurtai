from django.shortcuts import render
from .models import GuestbookEntry
from django.shortcuts import redirect
from .forms import GuestbookEntryForm


def index(request):
    entries = GuestbookEntry.objects.filter(status='active').order_by('-created_at')
    return render(request, 'guestbook/index.html', {'entries': entries})



def add_entry(request):
    if request.method == 'POST':
        form = GuestbookEntryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = GuestbookEntryForm()
    return render(request, 'guestbook/add_entry.html', {'form': form})

from django.shortcuts import get_object_or_404

def edit_entry(request, pk):
    entry = get_object_or_404(GuestbookEntry, pk=pk)
    if request.method == 'POST':
        form = GuestbookEntryForm(request.POST, instance=entry)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = GuestbookEntryForm(instance=entry)
    return render(request, 'guestbook/edit_entry.html', {'form': form})

def delete_entry(request, pk):
    entry = get_object_or_404(GuestbookEntry, pk=pk)
    if request.method == 'POST':
        email = request.POST.get('email')
        if email == entry.author_email:
            entry.delete()
            return redirect('index')
        else:
            error_message = "Email does not match!"
            return render(request, 'guestbook/delete_entry.html', {'entry': entry, 'error_message': error_message})
    return render(request, 'guestbook/delete_entry.html', {'entry': entry})
